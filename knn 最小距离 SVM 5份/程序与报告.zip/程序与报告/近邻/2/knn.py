import numpy as np
import math
from sklearn import neighbors

#读取训练数据
file = open("train.txt")
train_data = np.zeros((38,13))
test_data = np.zeros((111,13))
train_label = np.zeros((38,1))
test_label = np.zeros((111,1))
i = 0
for line in file:
  line = line.split(",")
  for j in range(0,13):
    train_data[i][j] = float(line[j+1])
    train_label[i] = float(line[0])

  i = i + 1
file.close()
#读取测试数据
file = open("test.txt")
i = 0
for line in file:
  line = line.split(",")
  for j in range(0, 13):
      test_data[i][j] = float(line[j + 1])
      test_label[i] = float(line[0])
  i = i + 1
file.close()
#归一化
mu = np.zeros((1,13))
sigma = np.zeros((1,13))

for i in range(0,13):
  mu[0][i] = np.mean(train_data[:,i])
  sigma[0][i] = np.var(train_data[:,i])

for i in range(0,38):
  for j in range(0,13):
    train_data[i][j] = (train_data[i][j] - mu[0][j])/(math.sqrt(sigma[0][j]))

for i in range(0, 13):
  mu[0][i] = np.mean(test_data[:, i])
  sigma[0][i] = np.var(test_data[:, i])

for i in range(0, 111):
  for j in range(0, 13):
    test_data[i][j] = (test_data[i][j] - mu[0][j]) / (math.sqrt(sigma[0][j]))

''' 训练KNN分类器 '''
clf = neighbors.KNeighborsClassifier(algorithm='kd_tree')
clf.fit(train_data, train_label)
answer = clf.predict(test_data)
count = 0
for i in range(0,111):
    if answer[i] == test_label[i]:
        count = count + 1

acc = count/111
print(acc)

