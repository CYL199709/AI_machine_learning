import numpy as np
import math
#读取训练数据
file = open("train.txt")
train_data = np.zeros((42,4))
test_data = np.zeros((30,4))
train_label = np.zeros((42,1))
test_label = np.zeros((30,1))
i = 0
for line in file:
  line = line.split(",")
  train_data[i][0] = float(line[0])
  train_data[i][1] = float(line[1])
  train_data[i][2] = float(line[2])
  train_data[i][3] = float(line[3])
  if line[4][5] == "s":
    train_label[i] = 1
  elif line[4][6] == "e":
    train_label[i] = 2
  else:
    train_label[i] = 3
  i = i + 1
file.close()
#读取测试数据
file = open("test.txt")
i = 0
for line in file:
  line = line.split(",")
  test_data[i][0] = float((line[0]))
  test_data[i][1] = float((line[1]))
  test_data[i][2] = float((line[2]))
  test_data[i][3] = float((line[3]))
  if line[4][5] == "s":
    test_label[i] = 1
  elif line[4][6] == "e":
    test_label[i] = 2
  else:
    test_label[i] = 3
  i = i + 1
file.close()
#归一化
mu = np.zeros((1,4))
sigma = np.zeros((1,4))

for i in range(0,4):
  mu[0][i] = np.mean(train_data[:,i])
  sigma[0][i] = np.var(train_data[:,i])

for i in range(0,42):
  for j in range(0,4):
    train_data[i][j] = (train_data[i][j] - mu[0][j])/(math.sqrt(sigma[0][j]))

for i in range(0, 4):
  mu[0][i] = np.mean(test_data[:, i])
  sigma[0][i] = np.var(test_data[:, i])

for i in range(0, 30):
  for j in range(0, 4):
    test_data[i][j] = (test_data[i][j] - mu[0][j]) / (math.sqrt(sigma[0][j]))

#求均值
A = []
B = []
C = []
for i in range(0,42):
  if train_label[i] == 1:
    A.append(train_data[i])
  elif train_label[i] == 2:
    B.append(train_data[i])
  else:
    C.append(train_data[i])

A = np.transpose(A,(1,0))
B = np.transpose(B,(1,0))
C = np.transpose(C,(1,0))
mean = np.zeros((3,4))
for j in range(0,4):
  mean[0][j] = np.mean(A[j])
  mean[1][j] = np.mean(B[j])
  mean[2][j] = np.mean(C[j])


count = 0
for i in range(0,30):

  dis1 = np.dot((test_data[i] - mean[0]).T , (test_data[i] - mean[0]))
  dis2 = np.dot((test_data[i] - mean[1]).T , (test_data[i] - mean[1]))
  dis3 = np.dot((test_data[i] - mean[2]).T , (test_data[i] - mean[2]))
  #print(dis1,dis2,dis3)
  if dis1 < dis2 and dis1 < dis3:
    pred = 1
  elif dis2 < dis1 and dis2 < dis3:
    pred = 2
  else:
    pred = 3
  if pred == test_label[i]:
    count = count + 1
  else:
    print(i,pred,test_label[i])

print("准确率：",count/30)